package com.Railway;


import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;






import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Details
 */
public class Details extends HttpServlet {
	private static final long serialVersionUID = 1L;




	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Details() {
		super();
		// TODO Auto-generated constructor stub
	}





	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		response.setContentType("text/html");


		try {
			HttpSession session=request.getSession();
			int count=(int)session.getAttribute("hello");
			System.out.println(count);
			int count1=(int)session.getAttribute("hi");
			int total=count+count1;
			System.out.println(count1);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded Successfully..");
			//creating connection
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
			con.setAutoCommit(true);
			System.out.println("connection established successfully..");
			String first=request.getParameter("firstname");
			String last=request.getParameter("lastname");
			String age=request.getParameter("age");
			String phone=request.getParameter("phonenumber");
			String seatnumber=request.getParameter("seatnumber");
			String Trainnumber=request.getParameter("Trainnumber");
			System.out.println(first+last+age+phone);
			PreparedStatement st9=con.prepareStatement("select AGE from Details where  SEATNUMBER=?");
			st9.setString(1, seatnumber);
			ResultSet rs4=st9.executeQuery();
			PreparedStatement st10=con.prepareStatement("update SeatAllotment set STATUS='y' where  SEATNUMBER=? and STATUSS=?");
			st10.setString(1, seatnumber);
			st10.setString(2, Trainnumber);
			st10.executeUpdate();
			if(rs4.next()==false){
				PreparedStatement st5=con.prepareStatement("select count(*) from Details");
				ResultSet t=st5.executeQuery();
				t.next();
				int fg=t.getInt(1);
				PreparedStatement st=con.prepareStatement("insert into Details values(?,?,?,?,?,?,?)");
				st.setString(1, first);
				st.setString(2, last);
				st.setString(3, age);
				st.setString(4, phone);
				st.setString(5, seatnumber);
				st.setInt(6, fg);
				st.setString(7, Trainnumber);
				st.executeUpdate();
			    PreparedStatement st1=con.prepareStatement("select count(*) from Details");
				ResultSet k=st1.executeQuery();
				k.next();
				int count2=k.getInt(1);
				con.commit();


				System.out.println(count2);
				System.out.println(total);

				int s=0;
				//for(int i=1;i<=count;i++){
				// s=s+1;
				// if(s!=count){
				int i=1;
				/*while(s!=count){
                 PrintWriter pw=response.getWriter();
                 pw.print("tickets"+" "+"booked "+"please enter details of another "+"ticket");
                    RequestDispatcher rd=request.getRequestDispatcher("Details.html");
                    rd.include(request, response);
                    s=s+1;
                }*/
				// }
				if(count2==total){
					System.out.println("entered");
					HttpSession tr1=request.getSession();
					String tr =(String)tr1.getAttribute("gasp");




					PreparedStatement str1=con.prepareStatement("select FARE from Trains where TRAIN_NUMBER=?");
					str1.setString(1, tr);

					ResultSet iop=str1.executeQuery();
					PreparedStatement ps1= con.prepareStatement("select FARE from Trains where TRAIN_NUMBER=?");
					ps1.setString(1,Trainnumber);

					ResultSet rs=ps1.executeQuery();
					rs.next();
					HttpSession tr8=request.getSession();
					int t8 =(int)tr8.getAttribute("hello");
					int tyi=(int)tr8.getAttribute("hi");
					int a=rs.getInt("FARE");
					int total1=t8*a;
					/**HttpSession tr8=request.getSession();
					int t8 =(int)tr8.getAttribute("hello");
					int tyi=(int)tr8.getAttribute("hi");
					int a=rs.getInt("FARE");
					int total1=t8*a;
					PrintWriter out=response.getWriter();
					System.out.println(a);
					PreparedStatement psp= con.prepareStatement("select * from Details where indexer >=? ");
					psp.setInt(1, tyi);
					ResultSet rds=psp.executeQuery();
					while(rds.next()){
						out.print("<html><head><body>");
						out.print("<table border=3>");
						out.print("<tr>");
						out.print("firstname");
						out.print("lastname");
						out.print("age");
						out.print("phonenumber");
						out.print("seatnumber");
					    out.print("</tr>");
					    out.print("<tr><td>"+rds.getString(1)+" "+rds.getString(2)+" "+rds.getString(3)+" "+rds.getString(4)+" "+rds.getString(5)+"</td></tr>");}
						out.print("</table>");
						out.print("</body></head></html>");**/
					PrintWriter out=response.getWriter();
					out.print("<html><head><body>");
					out.print("<h3>"+total1+"</h3>");
					out.print("</body></head></html>");
					RequestDispatcher rd=request.getRequestDispatcher("Payments.html");
					rd.include(request, response);
				}

				while(count2!=total){
					PrintWriter pw=response.getWriter();
					pw.print("<html><head><body>");
					pw.print("<h3>Details saved successfully please enter the details of another person</h3>");
					pw.print("</body></head></html>");
					RequestDispatcher rd=request.getRequestDispatcher("NewFile.html");
					rd.include(request, response);
					break;
				}
			}
			else{
				PrintWriter out=response.getWriter();
				out.print("seat is already booked. please select another seat");
				RequestDispatcher rd=request.getRequestDispatcher("NewFile.html");
				rd.include(request, response);
			}

		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}






}