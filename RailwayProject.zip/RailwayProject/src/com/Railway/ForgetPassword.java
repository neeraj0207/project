package com.Railway;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ForgetPassword
 */
public class ForgetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgetPassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
			String UserName=request.getParameter("username");
		String OldPassword=request.getParameter("password");
		String ConfirmPassword=request.getParameter("newpassword");
		Class.forName("oracle.jdbc.driver.OracleDriver");
        System.out.println("Driver loaded successfully");
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","neeraj0207");
        System.out.println("connection is established");
        PreparedStatement srcv=con.prepareStatement("update Account set password=? where username=? and password=? ");
        srcv.setString(3,OldPassword);
        srcv.setString(2,UserName);
        srcv.setString(1, ConfirmPassword);
        int swrt=srcv.executeUpdate();
        
        response.sendRedirect("Logins.html");
        con.commit();
		
}
	 catch(SQLException|ClassNotFoundException e){
         System.out.println(e);
		
	
	 }	}
}
