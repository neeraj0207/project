package com.Railway;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CreateAccount
 */
public class CreateAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateAccount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		try{
			String FirstName=request.getParameter("firstname");
		    String LastName=request.getParameter("lastname");
		int Age=Integer.parseInt(request.getParameter("age"));
		String PhoneNumber=request.getParameter("phonenumber");
		String AlternatePhoneNumber=request.getParameter("alternatephonenumber");
		String UserName=request.getParameter("username");
		String Password=request.getParameter("password");
		String ConfirmPassword=request.getParameter("confirmpassword");
		System.out.println(FirstName+LastName+Age);
		Class.forName("oracle.jdbc.driver.OracleDriver");
        System.out.println("Driver loaded successfully");
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","neeraj0207");
        System.out.println("connection is established");
        PreparedStatement sr=con.prepareStatement("insert into Account values(?,?,?,?,?,?,?,?)");
        sr.setString(1,FirstName);
        sr.setString(2,LastName);
        sr.setInt(3,Age);
        sr.setString(4,PhoneNumber);
        sr.setString(5,AlternatePhoneNumber);
        sr.setString(6,UserName);
        sr.setString(7,Password);
        sr.setString(8,ConfirmPassword);
        int sw=sr.executeUpdate();
        con.commit();
        response.sendRedirect("Logins.html");
	}
		 catch(SQLException|ClassNotFoundException e){
             System.out.println(e);
		
	}
		}
}