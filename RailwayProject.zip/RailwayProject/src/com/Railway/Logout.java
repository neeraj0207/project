package com.Railway;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Logout
 */
public class Logout extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Logout() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("Driver loaded Successfully..");
		//creating connection
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
		con.setAutoCommit(true);
		System.out.println("connection established successfully..");
		HttpSession tr8=request.getSession();
		int t8 =(int)tr8.getAttribute("hello");
		int tyi=(int)tr8.getAttribute("hi");
		
		PrintWriter out=response.getWriter();
		
		PreparedStatement psp= con.prepareStatement("select * from Details where indexer >=? ");
		psp.setInt(1, tyi);
		ResultSet rds=psp.executeQuery();
		while(rds.next()){
			out.print("<html><head><body>");
			out.print("<table border=3>");
			out.print("<tr>");
	        out.print("<th>FIRST_NAME</th>");
			out.print("<th>LAST_NAME</th>");
			out.print("<th>AGE</th>");
			out.print("<th>PHONE_NUMBER</th>");
			out.print("<th>SEAT_NUMBER</th>");
			out.print("<th>TRAIN_NUMBER</th>");
		    out.print("</tr>");
		    out.print("<br>");
		    out.print("<tr>");
		    out.print("<td>");
		    out.print(rds.getString(1));
		    out.print("</td>");
		    out.print("<td>");
		    out.print(rds.getString(2));
		    out.print("</td>");
		    out.print("<td>");
		    out.print(rds.getString(3));
		    out.print("</td>");
		    out.print("<td>");
		    out.print(rds.getString(4));
		    out.print("</td>");
		    out.print("<td>");
		    out.print(rds.getString(5));
		    out.print("</td>");
		    out.print("<td>");
		    out.print(rds.getString(7));
		    out.print("</td>");
		    out.print("</tr>");
		    out.print("</table>");
		    out.print("<button onclick='window.print()'>Print this page</button>");
			out.print("</body></head></html>");
		}
		HttpSession session=request.getSession();
        session.invalidate();
	
        out.print("logged out succesfully");
      // response.sendRedirect("Logins.html");
       RequestDispatcher rd=request.getRequestDispatcher("Diaplay");
       rd.include(request, response);
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}


