package com.Railway;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Cancel
 */
public class Cancel extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Cancel() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		try{
			String TrainNumber=request.getParameter("trainnumber");
			String FirstName=request.getParameter("firstname");
			String LastName=request.getParameter("lastname");
			String seatNumber=request.getParameter("seatnumber");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded Successfully..");
			//creating connection
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
			con.setAutoCommit(true);
			System.out.println("connection established successfully..");
			PreparedStatement pspk= con.prepareStatement("delete from Details where SEATNUMBER=?");
			pspk.setString(1, seatNumber);
		    int rsq=pspk.executeUpdate();
		    con.commit();
		    PrintWriter jh=response.getWriter();
		    if(rsq>0){
		    	PreparedStatement pspk1= con.prepareStatement("update SeatAllotment set STATUS='n' where SEATNUMBER=?");
		    	pspk1.setString(1, seatNumber);
		    	pspk1.executeUpdate();
		    	con.commit();
		    	jh.print("<html><head><body>");
		    	jh.print("<h3>Ticket Canceled Sucessfully.</h3>");
		    	jh.print("<a href='Confirmation.html'><button>Back</button></a>");
		    	jh.print("</body></head></html>");
		    	
		    			    }
		    else{
		    	jh.print("Entered details are incorrect.");
		    	RequestDispatcher rd=request.getRequestDispatcher("Checking.html");
		    	rd.include(request, response);
		    }
           
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}







