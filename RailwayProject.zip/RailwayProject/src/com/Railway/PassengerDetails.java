package com.Railway;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PassengerDetails
 */
public class PassengerDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PassengerDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String no=request.getParameter("no");
		PrintWriter out=response.getWriter();
		System.out.println("hello");
		try{	
			Class.forName("oracle.jdbc.driver.OracleDriver");  
		    System.out.println("Driver loaded Successfully..");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
		    con.setAutoCommit(true); 
		    System.out.println("connection established successfully..");    
		   // PreparedStatement ps=con.prepareStatement("select * from Details where trainnumber=?");
		   // ps.setString(1, no);	    
		    //ResultSet rs=ps.executeQuery();
		    //while(rs.next()){
			//pw.write("<html><head><body>");
			//pw.write("<table>");
			//pw.write("<tr>");
			//pw.write(rs.getString(0)+rs.getString(1)+rs.getString(2)+rs.getString(3)+rs.getString(4)+rs.getString(5)+rs.getString(6)+rs.getString(7));
			//pw.write("</tr>");
			//pw.write("</table>");
			//pw.write("</body><head></html>");
			//RequestDispatcher rs1=request.getRequestDispatcher("adminmenu.html");
			//rs1.include(request, response);
		    //}
		    PreparedStatement ps= con.prepareStatement("select * from Details where trainnumber=? ");
			ps.setString(1, no);
			ResultSet rs=ps.executeQuery();
			
				
				
			
			while(rs.next()){
				out.print("<html><head><body>");
				out.print("<table border=3>");
				out.print("<tr>");
				out.print("firstname");
				out.print("lastname");
				out.print("age");
				out.print("phonenumber");
				out.print("seatnumber");
			    out.print("</tr>");
			    out.print("<tr><td>"+rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+"</td></tr>");
				out.print("</table>");
				
			    out.print("</body></head></html>");
			}
			
			if(rs.next()==false){
			   out.print("<html><head><body>");
			   out.print("<h2>No tickets booked</h2>");
			  out.print("</body><head></html>");
			   RequestDispatcher rs1=request.getRequestDispatcher("adminmenu.html");
			   rs1.include(request, response);
		 }
		}
	
		catch(Exception e){
				
			}
	}
	

}
