package com.Railway;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PassengerCount
 */
public class PassengerCount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PassengerCount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String no=request.getParameter("no");
		PrintWriter pw=response.getWriter();
		System.out.println("hello");
		try {	
			Class.forName("oracle.jdbc.driver.OracleDriver");  
		    System.out.println("Driver loaded Successfully..");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
		    con.setAutoCommit(true); 
		    System.out.println("connection established successfully..");    
		    PreparedStatement ps=con.prepareStatement("select count(*) from Details where trainnumber=?");
		    ps.setString(1, no);	    
		    ResultSet rs=ps.executeQuery();
			rs.next();
	    	int count1=rs.getInt(1);
		    System.out.println(count1);
		   if(count1>0){
			 pw.write("<html><head><body>");
			 pw.write("<h2>Number of tickets booked for "+no+" is "+count1+" </h2>");
			 pw.write("</body><head></html>");
			 RequestDispatcher rs1=request.getRequestDispatcher("adminmenu.html");
			   rs1.include(request, response);
		  
		   }
		   else{
			   pw.write("<html><head><body>");
			   pw.write("<h2>No tickets booked</h2>");
			  pw.write("</body><head></html>");
			   RequestDispatcher rs1=request.getRequestDispatcher("adminmenu.html");
			   rs1.include(request, response);
		 }
		}
		
		catch(Exception e){
				
			}
			
	}
}
