package com.Railway;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteTrain
 */
public class DeleteTrain extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteTrain() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String no=request.getParameter("no");
		   PrintWriter pw=response.getWriter();
		try {
	    	
		    //creating driver
		      Class.forName("oracle.jdbc.driver.OracleDriver");
		    System.out.println("Driver loaded Successfully..");
		    //creating connection
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
		    con.setAutoCommit(true);
		    System.out.println("connection established successfully..");
		    PreparedStatement ps=con.prepareStatement("delete from trains where train_number=?");
		    ps.setString(1, no);

		   int w=ps.executeUpdate();
		   con.commit();
		   System.out.println("deleted ");
		   if(w>0){
			   pw.write("<html><head><body>");
			   pw.write("<h2>Deleted Successfully</h2>");
			   pw.write("</body><head></html>");
		   response.sendRedirect("adminmenu.html");
			}
		   else{
			
			   pw.write("<html><head><body>");
			   pw.write("<h2>Sorry entered train number is incorrect</h2>");
			   pw.write("</body><head></html>");
			   RequestDispatcher rs=request.getRequestDispatcher("deleteTrain.html");
			   rs.include(request, response);
		   }
		}
			catch(Exception e){
				
			}
			
	}

}
