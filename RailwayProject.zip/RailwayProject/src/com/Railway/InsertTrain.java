package com.Railway;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertTrain
 */
public class InsertTrain extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertTrain() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  String no=request.getParameter("no");
	  String name=request.getParameter("name");
	  String departs=request.getParameter("departs");
	  String from=request.getParameter("from");
	  String to=request.getParameter("to");
	  int fare=Integer.parseInt(request.getParameter("fare"));
	  String time=request.getParameter("time");
	try {
	    	
	    //creating driver
	      Class.forName("oracle.jdbc.driver.OracleDriver");
	    System.out.println("Driver loaded Successfully..");
	    //creating connection
	    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
	    con.setAutoCommit(true);
	    System.out.println("connection established successfully..");
	    PreparedStatement ps=con.prepareStatement("insert into trains values(?,?,?,?,?,?,?)");
	    ps.setString(1, no);
	    ps.setString(2, name);
	    ps.setString(3, departs);
	    ps.setString(4, from);
	    ps.setString(5, to);
	    ps.setInt(6, fare);
	    ps.setString(7, time);
	   ps.executeUpdate();
	   con.commit();
	   System.out.println("inserted ");
	   response.sendRedirect("adminmenu.html");
		}
		catch(Exception e){
			
		}
		
	}

}
