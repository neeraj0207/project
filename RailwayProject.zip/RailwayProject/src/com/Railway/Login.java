package com.Railway;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		try{
			String Username=request.getParameter("uname");
			String Password=request.getParameter("psw");
			
			
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("Driver loaded successfully");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","neeraj0207");
            System.out.println("connection is established");
            
           PreparedStatement ps1=con.prepareStatement("select * from Account where username=? and password=? ");
           ps1.setString(1, Username);
           ps1.setString(2, Password);
           
           ResultSet r=ps1.executeQuery();
            if(r.next()){
            	
            
            PreparedStatement ps=con.prepareStatement("insert into LoginForm values(?,?)");
          
            ps.setString(1,Username);
            ps.setString(2,Password);
            
            int cs=ps.executeUpdate();
            if(cs>0){
            	HttpSession hs=request.getSession();
            	hs.setAttribute(Username, 1);
            	hs.setAttribute(Password, 2);
            
            System.out.println("welcome");
            response.sendRedirect("Confirmation.html");
            con.commit();
            
            
           }
            else{
             RequestDispatcher rd=request.getRequestDispatcher("Logins.html");
             PrintWriter frt=response.getWriter();
             frt.print("Login Credientials are wrong. please enter correct information");
             rd.include(request,response);
            }
            }
            else{
                RequestDispatcher rd=request.getRequestDispatcher("Logins.html");
                PrintWriter frt=response.getWriter();
                frt.print("Login Credientials are wrong. please enter correct information");
                rd.include(request,response);
               }
        }
            catch(SQLException|ClassNotFoundException e){
                System.out.println(e);
            
            }
	}
	}