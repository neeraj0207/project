package com.Railway;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Alotment
 */
public class Alotment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Alotment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("Driver loaded Successfully..");
		//creating connection
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
		con.setAutoCommit(true);
		System.out.println("connection established successfully..");
		PreparedStatement st9=con.prepareStatement("select Seatnumber from SeatAllotment where  STATUS='n'");
		ResultSet tyg=st9.executeQuery();
		PrintWriter er=response.getWriter();
		er.print("<html><head><body>");
		
		while(tyg.next()){
			er.println("<h4>"+tyg.getString(1)+"</h4>");
			
			
		}
		
		er.print("<a href='NewFile.html'>BacK</a>");
		er.print("</body></head></html>");
		
		}
	
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
}
