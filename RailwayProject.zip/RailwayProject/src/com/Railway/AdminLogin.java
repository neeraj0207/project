package com.Railway;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

 

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

/**
 * Servlet implementation class AdminLogin
 */
public class AdminLogin extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

 

    /**
     * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
     */
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        String username=request.getParameter("user");
        String pass=request.getParameter("pass");
        try {
            
            //creating driver
          Class.forName("oracle.jdbc.driver.OracleDriver");
        System.out.println("Driver loaded Successfully..");
        //creating connection
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
        con.setAutoCommit(true);
        System.out.println("connection established successfully..");
        PreparedStatement ps=con.prepareStatement("select * from admin where username=? and password=?");
        ps.setString(1, username);
        ps.setString(2, pass);
        ResultSet rs=ps.executeQuery();
        if(rs.next()){
            response.sendRedirect("adminmenu.html");
        }
        else{
            RequestDispatcher rd=request.getRequestDispatcher("adminLogin.html");
            rd.include(request, response);
        }
        
        
        
        }
        catch(Exception e){
            
        }
        
    }

 

}