package com.Railway;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Train
 */
public class Train extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Train() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		try{
			String Date=request.getParameter("date");
			String From=request.getParameter("from");
			String To=request.getParameter("to");
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("Driver loaded successfully");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","neeraj0207");
            System.out.println("connection is established");
            System.out.println(Date+From+To);
            PreparedStatement sw=con.prepareStatement("insert into Train ( DATEOF, FROM_STATION, TO_STATION) values(?,?,?)");
            sw.setString(1,Date);
            sw.setString(2,From);
            sw.setString(3,To);
            
            
            int scr=sw.executeUpdate();
            
            if(scr>0){
            	
            	HttpSession ty=request.getSession();
            	ty.setAttribute("Date", Date);
            	ty.setAttribute("From", 2);
            	ty.setAttribute("To", 3);
            	
            System.out.println("Journey Planed");
           // if(From.equals("bhimavaram")&& To.equals("vizag")){
           // 	System.out.println("Date");
          //  response.sendRedirect("List.html");
          //  con.commit();
          //  }
          //  else{
           // 	RequestDispatcher rd=request.getRequestDispatcher("Train.html");
           //     rd.include(request,response);
          //  }
            
            PreparedStatement sw1=con.prepareStatement("select * from Trains where FROM_STATION=? and TO_STATION=?");
            
            sw1.setString(1,From);
            sw1.setString(2,To);
            ResultSet rd=sw1.executeQuery();
            System.out.println("hello");
            PrintWriter out=response.getWriter();
            while (rd.next()){
            	
            	
            	out.print("<html><head><body>");
				out.print("<table border=3>");
				out.print("<tr>");
		        out.print("<th>TRAIN_NUMBER</th>");
				out.print("<th>TRAIN_NAME</th>");
				out.print("<th>DEPARTS</th>");
				out.print("<th>FROM_STATION</th>");
				out.print("<th>TO_STATION</th>");
				out.print("<th>FARE</th>");
				out.print("<th>TIME</th>");
			    out.print("</tr>");
			    out.print("<br>");
			    out.print("<tr>");
			    out.print("<td>");
			    out.print(rd.getString(1));
			    out.print("</td>");
			    out.print("<td>");
			    out.print(rd.getString(2));
			    out.print("</td>");
			    out.print("<td>");
			    out.print(rd.getString(3));
			    out.print("</td>");
			    out.print("<td>");
			    out.print(rd.getString(4));
			    out.print("</td>");
			    out.print("<td>");
			    out.print(rd.getString(5));
			    out.print("</td>");
			    out.print("<td>");
			    out.print(rd.getString(6));
			    out.print("</td>");
			    out.print("<td>");
			    out.print(rd.getString(7));
			    out.print("</td>");
			    out.print("</tr>");
			    out.print("</table>");
			    
				out.print("</body></head></html>");
				 
            }
            PreparedStatement sw7=con.prepareStatement("select * from Trains where FROM_STATION=? and TO_STATION=?");
        	out.print("<html><head><body>");
			out.print("<a href='Ticket.html'><button>Submit</button></a>");
			out.print("</body></head></html>");
           }
            else{
             RequestDispatcher rd=request.getRequestDispatcher("Train.html");
             rd.include(request,response);
            }
           
        }
            catch(Exception e){
                System.out.println(e);
            
            }
	}
	
}