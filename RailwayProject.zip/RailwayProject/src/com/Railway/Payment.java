package com.Railway;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Payment
 */
public class Payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Payment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		try{
		        
		        Class.forName("oracle.jdbc.driver.OracleDriver");
		        System.out.println("Driver loaded Successfully..");
		        //creating connection
		        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
		        con.setAutoCommit(true);
		        System.out.println("payment done");
		        String holdername=request.getParameter("holdername");
		        String cardnumber=request.getParameter("cardnumber");
		        String validdate=request.getParameter("vdate");
		        int cvv=Integer.parseInt(request.getParameter("cvv"));
		        PreparedStatement df=con.prepareStatement("insert into Payments values(?,?,?,?)");
		        df.setString(1, holdername);
		        df.setString(2, cardnumber);
		        df.setString(3, validdate);
		        df.setInt(4, cvv);
		        df.executeUpdate();
		        PrintWriter out=response.getWriter();
		        out.print("ticked booked succesfully");
		                    out.print("<html><head><body>");
		                    out.print("<a href='Logout'>view</a>");
		                    out.print("</body></head></html>");
		                    
		}
		
		        catch(Exception e){
		            
		        }
		    }

		 

		}
		 

