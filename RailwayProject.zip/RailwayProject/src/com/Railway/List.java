package com.Railway;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class List
 */
public class List extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public List() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String selection=request.getParameter("hsy");
		System.out.println(selection);
	
try{
        
        Class.forName("oracle.jdbc.driver.OracleDriver");
        System.out.println("Driver loaded Successfully..");
        //creating connection
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","neeraj0207");
        con.setAutoCommit(true);
        System.out.println("connection established successfully..");
        HttpSession session=request.getSession();
        String fur=(String)session.getAttribute("Date");
        session.setAttribute("gasp", selection);
        System.out.println(fur);
        PreparedStatement st5=con.prepareStatement("update Train set selection=? where DATEOF=?");
        st5.setString(1, selection);
        st5.setString(2, fur);
        ResultSet u=st5.executeQuery();
        u.next();
        con.commit();
        response.sendRedirect("Ticket.html");
        
}
catch(Exception e){
    
}
	}
}
